#!/bin/sh
# mmchealth installer - Copyright (C) 2026 SECRT Workshop Tech (https://secrtworkshop.org)
# Licensed under the GNU GPL, version 2 or later. See COPYING.
set -e

BIN="mmchealth"
DEST="/usr/local/bin"
SRC_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [ "$1" = "--uninstall" ]; then
    ACTION=uninstall
else
    ACTION=install
fi

if [ "$ACTION" = "install" ] && [ ! -f "$SRC_DIR/$BIN" ]; then
    echo "Error: '$BIN' binary not found next to install.sh" >&2
    exit 1
fi

printf "%s %s %s /usr/local/bin (requires sudo). Continue? [Y/n] " \
    "$([ "$ACTION" = install ] && echo Install || echo Remove)" "$BIN" \
    "$([ "$ACTION" = install ] && echo to || echo from)"
read -r ans
case "$ans" in [nN]*) echo "Aborted."; exit 1;; esac

if [ "$(id -u)" -ne 0 ]; then
    if ! command -v sudo >/dev/null 2>&1; then
        echo "Error: sudo not found; run this script as root." >&2
        exit 1
    fi
    echo "Requesting administrator privileges..."
    SUDO="sudo"
    $SUDO -v
else
    SUDO=""
fi

if [ "$ACTION" = "uninstall" ]; then
    $SUDO rm -f "$DEST/$BIN"
    echo "Removed $DEST/$BIN"
    exit 0
fi

$SUDO mkdir -p "$DEST"
$SUDO install -o root -g root -m 0755 "$SRC_DIR/$BIN" "$DEST/$BIN"

# Repair ownership/permissions of the install dir entry and SELinux label if present
$SUDO chown root:root "$DEST/$BIN"
$SUDO chmod 0755 "$DEST/$BIN"
if command -v restorecon >/dev/null 2>&1; then
    $SUDO restorecon -F "$DEST/$BIN" 2>/dev/null || true
fi

echo "Installed: $DEST/$BIN"
"$DEST/$BIN" --version | head -1
echo "Run 'sudo mmchealth' to read your eMMC device(s)."
