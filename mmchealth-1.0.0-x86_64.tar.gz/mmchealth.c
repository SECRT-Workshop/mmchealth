/*
 * mmchealth - human readable eMMC health and information reporter
 * Copyright (C) 2026 SECRT Workshop Tech <https://secrtworkshop.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <ctype.h>
#include <getopt.h>
#include <sys/ioctl.h>
#include <sys/stat.h>

#define PROG_NAME    "mmchealth"
#define PROG_VERSION "1.0.0"
#define ORG_NAME     "SECRT Workshop Tech"
#define ORG_URL      "https://secrtworkshop.org"

/* ---- EXT_CSD byte offsets (JEDEC JESD84-B51) ---- */
#define EC_CACHE_CTRL        33
#define EC_POWER_OFF_NOTIF   34
#define EC_DATA_SECTOR_SIZE  61
#define EC_GP_SIZE_MULT      143   /* 4 x 3 bytes: 143..154 */
#define EC_PARTITIONING_SUP  160
#define EC_BKOPS_EN          163
#define EC_PARTITION_CONFIG  179
#define EC_BUS_WIDTH         183
#define EC_HS_TIMING         185
#define EC_RPMB_SIZE_MULT    168
#define EC_HC_WP_GRP_SIZE    221
#define EC_HC_ERASE_GRP_SIZE 224
#define EC_BOOT_SIZE_MULT    226
#define EC_SEC_COUNT         212   /* 4 bytes */
#define EC_REV               192
#define EC_STRUCTURE         194
#define EC_CARD_TYPE         196
#define EC_CACHE_SIZE        249   /* 4 bytes, in Kbit */
#define EC_FW_VERSION        254   /* 8 bytes */
#define EC_PRE_EOL_INFO      267
#define EC_LIFE_TIME_A       268
#define EC_LIFE_TIME_B       269
#define EC_VENDOR_HEALTH     270   /* 32 bytes */
#define EC_CMDQ_SUPPORT      308
#define EC_BKOPS_SUPPORT     502

/* ---- minimal copy of the kernel's MMC ioctl ABI (static, no headers needed) ---- */
struct mmc_ioc_cmd_local {
	int write_flag;
	int is_acmd;
	uint32_t opcode;
	uint32_t arg;
	uint32_t response[4];
	unsigned int flags;
	unsigned int blksz;
	unsigned int blocks;
	unsigned int postsleep_ns;
	unsigned int data_timeout_ns;
	unsigned int cmd_timeout_ms;
	uint32_t __pad;
	uint64_t data_ptr;
};
#define MMC_IOC_CMD_LOCAL _IOWR(0xB3, 0, struct mmc_ioc_cmd_local)
#define L_RSP_PRESENT (1 << 0)
#define L_RSP_CRC     (1 << 2)
#define L_RSP_OPCODE  (1 << 4)
#define L_RSP_SPI_S1  (1 << 7)
#define L_CMD_ADTC    (1 << 5)

static int use_color;
static int show_raw;
static int show_hex;

/* ---------- output helpers ---------- */
#define C_RESET (use_color ? "\033[0m"  : "")
#define C_BOLD  (use_color ? "\033[1m"  : "")
#define C_RED   (use_color ? "\033[31m" : "")
#define C_GRN   (use_color ? "\033[32m" : "")
#define C_YEL   (use_color ? "\033[33m" : "")
#define C_CYN   (use_color ? "\033[36m" : "")

static void section(const char *t)
{
	printf("\n%s%s== %s ==%s\n", C_BOLD, C_CYN, t, C_RESET);
}

static void row(const char *k, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void row(const char *k, const char *fmt, ...)
{
	char buf[256];
	__builtin_va_list ap;
	__builtin_va_start(ap, fmt);
	vsnprintf(buf, sizeof buf, fmt, ap);
	__builtin_va_end(ap);
	printf("  %-26s %s\n", k, buf);
}

static void print_version(void)
{
	printf("%s %s\n", PROG_NAME, PROG_VERSION);
	printf("Copyright (C) 2026 %s\n", ORG_NAME);
	printf("License GPLv2+: GNU GPL version 2 or later <https://gnu.org/licenses/gpl-2.0.html>\n");
	printf("This is free software: you are free to change and redistribute it.\n");
	printf("There is NO WARRANTY, to the extent permitted by law.\n\n");
	printf("Written by %s (%s).\n", ORG_NAME, ORG_URL);
}

static void print_help(void)
{
	printf(
"Usage: %s [OPTION]... [DEVICE]\n"
"Show human readable health and identity information for eMMC storage by\n"
"decoding the raw EXT_CSD register and the kernel's MMC sysfs attributes.\n"
"\n"
"With no DEVICE, all eMMC devices found (e.g. /dev/mmcblk0) are reported.\n"
"Reading EXT_CSD from a device normally requires root privileges.\n"
"\n"
"Options:\n"
"  -d, --device=DEV   eMMC block device to inspect (e.g. /dev/mmcblk0)\n"
"  -f, --file=FILE    decode a saved EXT_CSD instead of a live device; FILE may\n"
"                     be 512 raw bytes or the 1024-hex-digit text from debugfs\n"
"                     (/sys/kernel/debug/mmcN/mmcN:0001/ext_csd)\n"
"  -r, --raw          also show the raw register values next to decoded ones\n"
"  -x, --hexdump      print a full 512-byte EXT_CSD hex dump\n"
"      --no-color     disable colored output\n"
"  -h, --help         display this help and exit\n"
"  -V, -ver, --version  output version and license information and exit\n"
"\n"
"Lifetime values (EXT_CSD bytes 268/269) are reported by the controller in\n"
"10%% steps (0x01 = 0-10%% used ... 0x0A = 90-100%% used, 0x0B = exceeded).\n"
"%s shows the range and a rough midpoint estimate. These are the\n"
"device's own estimates; vendors implement them differently.\n"
"\n"
"%s %s\n"
"Copyright (C) 2026 %s\n"
"Website: %s\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License along\n"
"with this program; if not, write to the Free Software Foundation, Inc.,\n"
"51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA, or visit\n"
"<https://www.gnu.org/licenses/>.\n",
	PROG_NAME, PROG_NAME, PROG_NAME, PROG_VERSION, ORG_NAME, ORG_URL);
}

/* ---------- sysfs ---------- */
static int read_sysfs(const char *dev, const char *attr, char *out, size_t n)
{
	char path[512];
	FILE *f;
	snprintf(path, sizeof path, "/sys/block/%s/device/%s", dev, attr);
	f = fopen(path, "r");
	if (!f) { out[0] = 0; return -1; }
	if (!fgets(out, (int)n, f)) out[0] = 0;
	fclose(f);
	out[strcspn(out, "\r\n")] = 0;
	return out[0] ? 0 : -1;
}

static const char *vendor_name(unsigned id)
{
	switch (id) {
	case 0x02: case 0x03: case 0x45: return "SanDisk / Western Digital";
	case 0x11: return "Toshiba / Kioxia";
	case 0x13: case 0xFE: return "Micron";
	case 0x15: return "Samsung";
	case 0x27: return "Apacer";
	case 0x70: return "Kingston";
	case 0x90: return "SK hynix";
	default:   return NULL;
	}
}

/* ---------- EXT_CSD acquisition ---------- */
static int get_extcsd_ioctl(const char *devpath, uint8_t *buf)
{
	struct mmc_ioc_cmd_local ic;
	int fd = open(devpath, O_RDONLY);
	if (fd < 0) return -errno;
	memset(&ic, 0, sizeof ic);
	ic.opcode = 8; /* SEND_EXT_CSD */
	ic.flags = L_RSP_SPI_S1 | L_RSP_PRESENT | L_RSP_CRC | L_RSP_OPCODE | L_CMD_ADTC;
	ic.blksz = 512;
	ic.blocks = 1;
	ic.data_ptr = (uint64_t)(uintptr_t)buf;
	if (ioctl(fd, MMC_IOC_CMD_LOCAL, &ic) < 0) {
		int e = errno;
		close(fd);
		return -e;
	}
	close(fd);
	return 0;
}

static int get_extcsd_file(const char *path, uint8_t *buf)
{
	unsigned char raw[8192];
	size_t n, i, digits = 0;
	FILE *f = fopen(path, "rb");
	if (!f) return -errno;
	n = fread(raw, 1, sizeof raw, f);
	fclose(f);
	if (n == 512) { memcpy(buf, raw, 512); return 0; }
	for (i = 0; i < n && digits < 1024; i++) {
		int c = raw[i], v;
		if (c == 'x' || c == 'X') { /* drop a preceding "0" of a 0x prefix */
			if (digits && raw[i-1] == '0') digits--;
			continue;
		}
		if (isspace(c)) continue;
		if (c >= '0' && c <= '9') v = c - '0';
		else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
		else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
		else return -EINVAL;
		if (digits & 1) buf[digits / 2] |= (uint8_t)v;
		else buf[digits / 2] = (uint8_t)(v << 4);
		digits++;
	}
	return digits == 1024 ? 0 : -EINVAL;
}

/* ---------- decoding ---------- */
static const char *ext_csd_rev_name(unsigned r)
{
	switch (r) {
	case 0: return "4.0";   case 1: return "4.1";  case 2: return "4.2";
	case 3: return "4.3";   case 5: return "4.41"; case 6: return "4.5";
	case 7: return "5.0";   case 8: return "5.1 / 5.1A";
	default: return "unknown/newer";
	}
}

static void fmt_size(uint64_t bytes, char *out, size_t n)
{
	static const char *u[] = { "B", "KiB", "MiB", "GiB", "TiB" };
	double v = (double)bytes;
	int i = 0;
	while (v >= 1024.0 && i < 4) { v /= 1024.0; i++; }
	if (i == 0) snprintf(out, n, "%llu B", (unsigned long long)bytes);
	else if (i >= 3) snprintf(out, n, "%.2f %s (%.2f GB)", v, u[i], (double)bytes / 1e9);
	else snprintf(out, n, "%.2f %s", v, u[i]);
}

static void bar(int pct, char *out, size_t n)
{
	int i, filled = pct < 0 ? 0 : pct > 100 ? 100 : pct;
	filled = (filled + 2) / 5; /* 20 cells */
	if (n < 24) return;
	out[0] = '[';
	for (i = 0; i < 20; i++) out[1 + i] = i < filled ? '#' : '-';
	out[21] = ']'; out[22] = 0;
}

/* returns severity 0 ok, 1 warn, 2 critical, -1 unknown */
static int show_life(const char *label, uint8_t v)
{
	char b[32], line[200];
	const char *col = C_GRN;
	int sev = 0;

	if (v == 0) {
		row(label, "Not reported by this device%s", "");
		if (show_raw) row("", "(raw 0x%02X)", v);
		return -1;
	}
	if (v == 0x0B) {
		bar(100, b, sizeof b);
		snprintf(line, sizeof line, "%s %sEXCEEDED%s - over 100%% of rated life used",
			 b, C_RED, C_RESET);
		row(label, "%s", line);
		if (show_raw) row("", "(raw 0x%02X)", v);
		return 2;
	}
	if (v > 0x0B) {
		row(label, "Reserved value 0x%02X", v);
		return -1;
	}
	if (v >= 0x0A) { col = C_RED; sev = 2; }
	else if (v >= 0x08) { col = C_YEL; sev = 1; }
	bar(v * 10 - 5, b, sizeof b);
	snprintf(line, sizeof line, "%s %s~%d%% used%s  (range %d-%d%%, about %d%% remaining)",
		 b, col, v * 10 - 5, C_RESET, (v - 1) * 10, v * 10, 100 - (v * 10 - 5));
	row(label, "%s", line);
	if (show_raw) row("", "(raw 0x%02X)", v);
	return sev;
}

static void hexdump512(const uint8_t *e)
{
	int i, j;
	printf("\n%sRaw EXT_CSD (512 bytes)%s\n", C_BOLD, C_RESET);
	for (i = 0; i < 512; i += 16) {
		printf("  %03d: ", i);
		for (j = 0; j < 16; j++) printf("%02X%s", e[i + j], j == 7 ? "  " : " ");
		printf("\n");
	}
}

static void report(const char *name, const uint8_t *e, int have_sysfs)
{
	char s[128], size[64];
	uint64_t sec, cap;
	unsigned rev = e[EC_REV];
	int sa, sb, worst, i;
	const char *verdict, *vcol;

	printf("%s%s%s %s - eMMC health report%s\n", C_BOLD, PROG_NAME, C_RESET, name, "");

	section("Device");
	if (have_sysfs) {
		char t[96];
		unsigned id = 0;
		if (read_sysfs(name, "name", t, sizeof t) == 0) row("Product name", "%s", t);
		if (read_sysfs(name, "manfid", t, sizeof t) == 0) {
			const char *v;
			id = (unsigned)strtoul(t, NULL, 16);
			v = vendor_name(id);
			if (v) row("Manufacturer", "%s (ID 0x%02X)", v, id);
			else row("Manufacturer", "Unknown (ID 0x%02X, not in built-in table)", id);
		}
		if (read_sysfs(name, "oemid", t, sizeof t) == 0) row("OEM / application ID", "%s", t);
		if (read_sysfs(name, "serial", t, sizeof t) == 0) row("Serial number", "%s", t);
		if (read_sysfs(name, "date", t, sizeof t) == 0) row("Manufactured (MM/YYYY)", "%s", t);
		if (read_sysfs(name, "hwrev", t, sizeof t) == 0) row("Hardware revision", "%s", t);
		if (read_sysfs(name, "fwrev", t, sizeof t) == 0) row("Firmware revision (CID)", "%s", t);
	} else {
		row("Identity", "n/a (decoded from file; CID not available)");
	}
	{
		int printable = 1;
		for (i = 0; i < 8; i++) {
			if (e[EC_FW_VERSION + i] && !isprint(e[EC_FW_VERSION + i])) printable = 0;
		}
		if (printable && e[EC_FW_VERSION]) {
			memcpy(s, e + EC_FW_VERSION, 8); s[8] = 0;
			row("Firmware (EXT_CSD)", "%s", s);
		} else {
			char *p = s;
			for (i = 0; i < 8; i++) p += sprintf(p, "%02X", e[EC_FW_VERSION + i]);
			row("Firmware (EXT_CSD)", "0x%s", s);
		}
	}
	row("eMMC spec version", "%s%s", ext_csd_rev_name(rev), "");
	if (show_raw) row("", "(EXT_CSD_REV raw %u, structure %u)", rev, e[EC_STRUCTURE]);

	section("Capacity");
	sec = (uint64_t)e[EC_SEC_COUNT] | (uint64_t)e[EC_SEC_COUNT+1] << 8 |
	      (uint64_t)e[EC_SEC_COUNT+2] << 16 | (uint64_t)e[EC_SEC_COUNT+3] << 24;
	cap = sec * 512ULL;
	fmt_size(cap, size, sizeof size);
	row("User area", "%s", cap ? size : "n/a");
	if (show_raw) row("", "(SEC_COUNT %llu sectors)", (unsigned long long)sec);
	if (e[EC_BOOT_SIZE_MULT]) {
		fmt_size((uint64_t)e[EC_BOOT_SIZE_MULT] * 128 * 1024, size, sizeof size);
		row("Boot partitions", "2 x %s", size);
	}
	if (e[EC_RPMB_SIZE_MULT]) {
		fmt_size((uint64_t)e[EC_RPMB_SIZE_MULT] * 128 * 1024, size, sizeof size);
		row("RPMB partition", "%s", size);
	}
	{
		uint64_t unit = (uint64_t)e[EC_HC_WP_GRP_SIZE] * e[EC_HC_ERASE_GRP_SIZE] * 512 * 1024;
		for (i = 0; i < 4; i++) {
			uint64_t m = (uint64_t)e[EC_GP_SIZE_MULT + i*3] |
				     (uint64_t)e[EC_GP_SIZE_MULT + i*3 + 1] << 8 |
				     (uint64_t)e[EC_GP_SIZE_MULT + i*3 + 2] << 16;
			if (m) {
				char lbl[32];
				fmt_size(m * unit, size, sizeof size);
				snprintf(lbl, sizeof lbl, "General purpose %d", i + 1);
				row(lbl, "%s", size);
			}
		}
	}
	row("Logical sector size", "%s", (e[EC_DATA_SECTOR_SIZE] & 1) ? "4096 bytes (native)" : "512 bytes");

	section("Health");
	if (rev < 7) {
		row("Lifetime", "Not available (requires eMMC 5.0+, device is %s)", ext_csd_rev_name(rev));
		sa = sb = -1;
	} else {
		sa = show_life("Wear, Type A (SLC/boost)", e[EC_LIFE_TIME_A]);
		sb = show_life("Wear, Type B (MLC/TLC)", e[EC_LIFE_TIME_B]);
	}
	{
		uint8_t p = e[EC_PRE_EOL_INFO];
		const char *d;
		int sevp = -1;
		switch (p) {
		case 1: d = "Normal (reserved blocks healthy)"; sevp = 0; break;
		case 2: d = "WARNING - 80% of reserved blocks consumed"; sevp = 1; break;
		case 3: d = "URGENT - 90% of reserved blocks consumed"; sevp = 2; break;
		case 0: d = "Not defined"; break;
		default: d = "Reserved value"; break;
		}
		row("Reserved block status", "%s%s%s", sevp == 2 ? C_RED : sevp == 1 ? C_YEL : sevp == 0 ? C_GRN : "", d, C_RESET);
		if (show_raw) row("", "(PRE_EOL_INFO raw 0x%02X)", p);
		worst = sa > sb ? sa : sb;
		if (sevp > worst) worst = sevp;
	}
	if (worst < 0 && e[EC_PRE_EOL_INFO] == 0 && e[EC_LIFE_TIME_A] == 0 && e[EC_LIFE_TIME_B] == 0) {
		verdict = "UNKNOWN - this controller does not report health data"; vcol = C_YEL;
	} else if (worst >= 2) {
		verdict = "CRITICAL - back up data and plan replacement"; vcol = C_RED;
	} else if (worst == 1) {
		verdict = "WARNING - approaching end of life, back up data"; vcol = C_YEL;
	} else {
		verdict = "GOOD"; vcol = C_GRN;
	}
	row("Overall", "%s%s%s%s", C_BOLD, vcol, verdict, C_RESET);
	{
		int nz = 0;
		for (i = 0; i < 32; i++) if (e[EC_VENDOR_HEALTH + i]) nz = 1;
		if (nz && show_raw) {
			char hb[100], *p = hb;
			for (i = 0; i < 32; i++) p += sprintf(p, "%02X", e[EC_VENDOR_HEALTH + i]);
			row("Vendor health report", "%s", hb);
		} else if (nz) {
			row("Vendor health report", "present (vendor-specific; use --raw to view)");
		}
	}

	section("Features");
	{
		uint8_t ct = e[EC_CARD_TYPE];
		char m[160] = "";
		if (ct & 0x01) strcat(m, "HS26 ");
		if (ct & 0x02) strcat(m, "HS52 ");
		if (ct & 0x04) strcat(m, "DDR52-1.8V ");
		if (ct & 0x08) strcat(m, "DDR52-1.2V ");
		if (ct & 0x10) strcat(m, "HS200-1.8V ");
		if (ct & 0x20) strcat(m, "HS200-1.2V ");
		if (ct & 0x40) strcat(m, "HS400-1.8V ");
		if (ct & 0x80) strcat(m, "HS400-1.2V ");
		row("Supported speed modes", "%s", m[0] ? m : "n/a");
	}
	{
		static const char *bw[] = { "1-bit", "4-bit", "8-bit", "4-bit DDR", "8-bit DDR" };
		static const char *ht[] = { "Legacy", "High Speed", "HS200", "HS400" };
		uint8_t b = e[EC_BUS_WIDTH] & 0x0F, h = e[EC_HS_TIMING] & 0x0F;
		row("Current bus width", "%s", b < 5 ? bw[b] : "unknown");
		row("Current timing mode", "%s", h < 4 ? ht[h] : "unknown");
	}
	{
		uint32_t cs = e[EC_CACHE_SIZE] | e[EC_CACHE_SIZE+1] << 8 | e[EC_CACHE_SIZE+2] << 16 |
			      (uint32_t)e[EC_CACHE_SIZE+3] << 24;
		if (cs) {
			row("Cache size", "%u KiB (%s)", cs / 8,
			    (e[EC_CACHE_CTRL] & 1) ? "enabled" : "disabled");
		}
	}
	row("Background ops", "%s", e[EC_BKOPS_SUPPORT] & 1 ?
	    ((e[EC_BKOPS_EN] & 3) ? "supported, enabled" : "supported, not enabled") : "not supported");
	row("Command queueing", "%s", (rev >= 8 && (e[EC_CMDQ_SUPPORT] & 1)) ? "supported" : "not supported");
	row("Power-off notification", "%s", e[EC_POWER_OFF_NOTIF] ? "enabled" : "not enabled");

	printf("\n%sNote:%s lifetime values are estimates reported by the controller in\n"
	       "10%% steps; interpret them as rough guidance, not exact measurements.\n",
	       C_BOLD, C_RESET);
	if (show_hex) hexdump512(e);
}

/* ---------- device discovery ---------- */
static int is_emmc(const char *dev)
{
	char t[32];
	return read_sysfs(dev, "type", t, sizeof t) == 0 && strcmp(t, "MMC") == 0;
}

static int do_device(const char *devpath)
{
	uint8_t e[512];
	const char *name = strrchr(devpath, '/');
	int r;
	name = name ? name + 1 : devpath;
	r = get_extcsd_ioctl(devpath, e);
	if (r < 0) {
		fprintf(stderr, "%s: cannot read EXT_CSD from %s: %s\n", PROG_NAME, devpath, strerror(-r));
		if (r == -EACCES || r == -EPERM)
			fprintf(stderr, "%s: try again as root (e.g. sudo %s %s)\n", PROG_NAME, PROG_NAME, devpath);
		return 1;
	}
	report(name, e, 1);
	return 0;
}

int main(int argc, char **argv)
{
	static const struct option lo[] = {
		{ "device", required_argument, 0, 'd' },
		{ "file", required_argument, 0, 'f' },
		{ "raw", no_argument, 0, 'r' },
		{ "hexdump", no_argument, 0, 'x' },
		{ "no-color", no_argument, 0, 1 },
		{ "help", no_argument, 0, 'h' },
		{ "version", no_argument, 0, 'V' },
		{ 0, 0, 0, 0 }
	};
	const char *dev = NULL, *file = NULL;
	int c, i, rc = 0, nocolor = 0;

	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "-ver")) { print_version(); return 0; }
		if (!strcmp(argv[i], "--")) break;
	}
	while ((c = getopt_long(argc, argv, "d:f:rxhV", lo, NULL)) != -1) {
		switch (c) {
		case 'd': dev = optarg; break;
		case 'f': file = optarg; break;
		case 'r': show_raw = 1; break;
		case 'x': show_hex = 1; break;
		case 1: nocolor = 1; break;
		case 'h': print_help(); return 0;
		case 'V': print_version(); return 0;
		default:
			fprintf(stderr, "Try '%s --help' for more information.\n", PROG_NAME);
			return 2;
		}
	}
	if (optind < argc && !dev) dev = argv[optind];
	use_color = isatty(STDOUT_FILENO) && !nocolor && !getenv("NO_COLOR");

	if (file) {
		uint8_t e[512];
		int r = get_extcsd_file(file, e);
		if (r < 0) {
			fprintf(stderr, "%s: cannot decode %s: %s\n", PROG_NAME, file,
				r == -EINVAL ? "not a valid 512-byte or 1024-hex-digit EXT_CSD" : strerror(-r));
			return 1;
		}
		report("(file)", e, 0);
		return 0;
	}
	if (dev) return do_device(dev);

	{
		DIR *d = opendir("/sys/block");
		struct dirent *de;
		int found = 0;
		if (!d) { fprintf(stderr, "%s: cannot open /sys/block: %s\n", PROG_NAME, strerror(errno)); return 1; }
		while ((de = readdir(d))) {
			char p[300];
			if (strncmp(de->d_name, "mmcblk", 6) || strchr(de->d_name + 6, 'p') ||
			    strstr(de->d_name, "boot") || strstr(de->d_name, "rpmb") || !is_emmc(de->d_name))
				continue;
			snprintf(p, sizeof p, "/dev/%s", de->d_name);
			if (found++) printf("\n----------------------------------------\n\n");
			rc |= do_device(p);
		}
		closedir(d);
		if (!found) {
			fprintf(stderr, "%s: no eMMC devices found. Use -d DEVICE or -f FILE.\n", PROG_NAME);
			return 1;
		}
	}
	return rc;
}
